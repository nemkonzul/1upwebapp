describe("Dummy tests", () => {
 test('Wether "true" is "true" in JS?', () => {
   var result = true 
   // assert
   expect(result).toBe(true);
 });
})
